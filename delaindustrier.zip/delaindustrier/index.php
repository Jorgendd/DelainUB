<!DOCTYPE html>
<html>
  <head><meta http-equiv="Content-Type" content="text/html"; charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet"> 
    <link rel="stylesheet" type="text/css" href="main.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dela Industrier</title>
  </head>
  <body>
<div class="nav">
  <ul>
   <!-- <li>  <a href=""><img src="dela_industrierimg.png" style="height:100px;width:100px;"></a></li>  -->
    <li><a href="index.php">Hjem</a></li<br>
    <li><a href="omoss.php">Om oss</a></li><br>
    <li><a href="vaaretjenester.php">Tjenester</a></li><br>
    <li><a href="kontaktoss.php">Kontakt oss</a></li><br>
    
  </ul>
</div><br><br>
<div class="frontimageholder">
<img src="frontimageindustries.png" alt="industry" style="">
<div class="centered_text">
Dela Industrier UB
</div>
<a href="omoss.php"><button class="centered_button">Les mer om oss</button></a>
</div><br><br>
<div class="container_aboutus">
<img src="office.png">
<div class="container_aboutus_txt">
<p>Vårt produkt og vår idè: </p>
<p>som kan fjerne is og snø på trappa om vinteren...

</p>


</div>
</div>

<br><br><br><br>
<br><br><br><br>





<div class="container_aboutus">
<img src="mail.png">
<div class="container_aboutus_txt">
<p>Telefon</p>
<p>Facebook</p>
<p>E-post</p>
<p>Instagram</p>
</div>
</div>
<p></p>

  </body>
</html>
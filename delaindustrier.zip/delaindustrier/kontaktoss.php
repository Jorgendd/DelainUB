<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<title>Kontakt oss - Dela Industrier</title>
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
    body,nav{
    border:0px;
    padding:0px;
    font-family: 'Roboto Condensed', arial;
}
.section_contact{
    width:50%;
    margin-left:auto;
    margin-right:auto;
    display:block;
    position:relative;
}
.h1,p{
    float:left;
    font-size:24px;
}
@media screen and (max-width: 800px) {
  .section_contact{
      width:90%;
  
}
}
</style>
<body>
<?php include 'navbar.php';?>
<div class="section_contact">
<h2>Kontakt oss:</h2
<p>Dela industrier`s kontaktinformasjon:</p><br><br>
<p><a href="https://www.facebook.com/pg/DELA-Industrier-UB-101650587938425/about/?ref=page_internal">Dela industrier på facebook</a></p>

</div>

</body>
</html>
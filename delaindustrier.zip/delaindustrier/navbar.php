<style>
body,.navbar{
    margin:0;
    padding:0;
    font-family: 'Roboto Condensed', arial;
}


    .navbar{

	justify-content: space-around;
	align-items: center;
	min-height:8vh;
  background-color:#202020 ;
  width:100%;
  border-bottom: solid 1px white;


}

ul{
	justify-content: space-around;
	float:left;
  display:flex;
}

ul li{
	list-style-type: none;
}

ul a{
color:white;
text-decoration: none;
letter-spacing:1px;
font-size: 20px;
display:inline-block;
padding:3px;
margin:5px;
font-weight: bold;
}
ul a:hover{
	border-bottom: solid 3px #e7ad07;
}

</style>
<div class="navbar">
  <ul>
    <li><a href="index.php">Hjem</a></li>
    <li><a href="omoss.php">Om oss</a></li>
    <li><a href="vaaretjenester.php">Tjenester</a></li>
    <li><a href="kontaktoss.php">Kontakt oss</a></li>
  </ul>
</div>
<!DOCTYPE html>
<html>
<head>
<title>Om oss - Dela Industrier</title>
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<style>
    body,nav{
    border:0;
    padding:0;
    font-family: 'Roboto Condensed', arial;
}
.section_aboutus{
    width:50%;
    margin-left:auto;
    margin-right:auto;
    display:block;
    position:relative;
}
p{
    float:left;
     font-size:24px;
}
.aboutus_img{
     width:100%;
    margin-left:auto;
    margin-right:auto;
    display:block;
    position:relative;
}
@media screen and (max-width: 800px) {
  .section_aboutus{
      width:90%;
      
  
}
.p{
    font-size:18px;
}
}
</style>
<body>
   
<?php include 'navbar.php';?>
<div class="section_aboutus">
<h1>Om oss</h1>
<p>
DELA Industrier UB er en ungdomsbedrift. Vi er 9 elever som går andreåret el-teknologi <br>
og elektronikk på Askim VGS. I timene våre har vi jobbet med<br>
å utvikle og produsere et produkt som vi gjerne vil høre deres meninger om. <br>
Trykk på linken og gi oss din mening <a href="
https://l.facebook.com/l.php?u=https%3A%2F%2Fforms.office.com%2FPages%2FResponsePage.aspx%3Fid%3DDQSIkWdsW0yxEjajBLZtrQAAAAAAAAAAAAN__g_bqFhUMlhMOExUNzYwRkszN0tBU1JEN09URjhaVC4u%26origin%3DFacebook%26time%3D1572434841863%26fbclid%3DIwAR2lvkAAWlPuQPHEghp5daRwlkASfBE1-ywM7mTEwHLOloOz6as_lfgHRX4&h=AT0RsKla5ZMd1n0DNx8g3jX0DCnc6QpDAvdkc1O5mB6tlmxyZKJw0WtpajvtcyK_YpXN_14l4zxFU0-xJ3Ts3QDjWfyiUwxihbptamPcC2FIdSTJ0CkNU_JPuSouRutruF0iO-g_ixS29azA7DHdx58Q_WfL9RA3InKBKocAQ9EA05tBz-Ukw759Yp6JFV5NMoCj7ty5LRcZPhBj9ytauVeGBGE73IHvunoknqNpCugFZSxpNFj5Phih92ihXY-AA6onO_QhuIa5IoHE7ZJ_QvEjzv7fE_yLomAjDWCZ0-iH_TNZrjNcEUWlkWDevXKK0dEb-gIhc7nEnxpGD3lanqgNeQbtUspjA-UT0BIHh6izfZNr9LFymPm3YQLUtvRdTJrZbmhqFg8YYExhiocld8pK04S_HaEbC314S31-Y06GCDd-9MbVVRBmeElMZXgWeSim24uZF3Pv-xujPMEISKPUWorCcLAV53dfwJDPwk3LS0vvoDKtBUkjsMLMLoGrl3JxHw6asHTUKPNhN9JGUc64oeHI0o0m2r9YBvSdG-drFzbAHMSHeoknGghbu1HJ0dF1gmGcupYzy5FzV3-KxrbjUESPxyQMETzShNlSq4zs08I7pNviC0_Y_Xz7vkI">på vår markedsundersøkelse.</a><br>
</p>
<img src="dela_industrierimg.png" alt="filen kunne ikke lastes riktig"class="aboutus_img">
</div>

</body>
</html>
<!DOCTYPE html>
<html>
<head>
<title>Våre tjenester - Dela Industrier</title>
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<style>
    body,nav{
    border:0px;
    padding:0px;
    font-family: 'Roboto Condensed', arial;
}
.section_vaartjeneste{
    width:50%;
    margin-left:auto;
    margin-right:auto;
    display:block;
    position:relative;
    background-color:#313131;
    padding:10px;
    height:500px;
    color:white;
}

}
.section_vaartjeneste p{
    font-size:24px;
    color:white;
}
.material-icons{
 color:white;
 text-decoration:none;
}
@media screen and (max-width: 800px) {
  .section_vaartjeneste{
      width:90%;
  
}
}
</style>
<body>
<?php include 'navbar.php';?>
<div class="section_vaartjeneste">
<h2>Vårt produkt</h2>
<p>Vårt produkt er ment til å smelte vekk is på trappen din i erstatning for salt <br>
som tærer på treverk, skruer, spiker, varmematter som er dyrt <br>
og ser stygt ut og minsker behovet for varmekabler som er dyrt å legge ned. <br>
Vårt produkt skal være bærekraftig og  det skal være enkelt å bruke. <br>
Produktet vårt skal utifra varmelementer inne i produktet blåse varm luft som er ment <br>
til å smelte is på for eksempel trappen og blåse vekk vann som blir igjen</p><br>
<center>
<a href=""><i class="material-icons" style="font-size:48px;background-color:#e7ad07;border-radius:100px;padding:5px;">phone</i></a>
<a href=""><i class="material-icons"style="font-size:48px;background-color:#e7ad07;border-radius:100px;padding:5px;">email</i></a>
<a href=""><i class="material-icons"style="font-size:48px;background-color:#e7ad07;border-radius:100px;padding:5px;">person</i></a>
<h5>Kontakt oss dersom du har spørsmål</h5>
</center>
</div>
</body>
</html>